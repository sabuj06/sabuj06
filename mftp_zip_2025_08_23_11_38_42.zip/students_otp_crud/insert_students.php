<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);


include 'config.php';

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone_number = $_POST['phone_number'] ?? '';
$gender = $_POST['gender'] ?? '';
$department = $_POST['department'] ?? '';

$image_name = '';
if (isset($_FILES['student_image']['name']) && $_FILES['student_image']['error'] == 0) {
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $image_name = time() . "_" . basename($_FILES['student_image']['name']);
    $target_file = $target_dir . $image_name;
    move_uploaded_file($_FILES['student_image']['tmp_name'], $target_file);
}

$sql = "INSERT INTO students (name, email, phone_number, gender, department, image) 
        VALUES ('$name', '$email', '$phone_number', '$gender', '$department', '$image_name')";

if (mysqli_query($conn, $sql)) {
    echo "success";
} else {
    echo "error: " . mysqli_error($conn);
}

mysqli_close($conn); 
