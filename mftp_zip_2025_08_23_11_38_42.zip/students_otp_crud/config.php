<?php 
$servername="sql107.alchosting.xyz";
$username="alcy_39763543";
$password="oGlOikSHBzveHIA";
$dbname="alcy_39763543_u123456789_db";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
 die("Mysqli Connect Error". mysqli_connect_error());
}
?>